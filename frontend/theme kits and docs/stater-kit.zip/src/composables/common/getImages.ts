export function getImages(path: string) {
    return require('@/assets/images/' + path)
}