<template>
    <div class="form-group w-100">
        <div class="Typeahead Typeahead--twitterUsers">
            <div class="u-posRelative d-flex align-items-center">
                <svg class="search-bg svg-color">
                    <use href="@/assets/svg/icon-sprite.svg#search"></use>
                </svg>
                <input class="demo-input py-0 Typeahead-input form-control-plaintext w-100" type="text"
                    placeholder="Search Mofi .." title="">
            </div>
        </div>
    </div>
</template>
