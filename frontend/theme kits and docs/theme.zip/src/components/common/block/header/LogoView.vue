<template>
    <div class="header-logo-wrapper col-auto">
        <div class="logo-wrapper"><router-link to="/"><img class="img-fluid for-light" src="@/assets/images/logo/logo.png"
                    alt="" /><img class="img-fluid for-dark" src="@/assets/images/logo/logo_light.png"
                    alt="" /></router-link></div>
    </div>
</template>