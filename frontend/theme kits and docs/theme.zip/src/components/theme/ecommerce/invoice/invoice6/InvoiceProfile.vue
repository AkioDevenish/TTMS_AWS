<template>
    <div class="row">
        <div class="col-md-4">
            <div class="d-flex">
                <div class="media-left"><img class="media-object rounded-circle img-60" src="@/assets/images/user/1.jpg"
                        alt=""></div>
                <div class="flex-grow-1 m-l-20">
                    <h4 class="media-heading">Johan Deo</h4>
                    <p>JohanDeo@gmail.com<br><span>555-555-5555</span></p>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="text-md-end" id="project">
                <h6>Project Description</h6>
                <p>You're Only As Good As Your Last Collection, Which Is An Enormous Pressure. Jeans Represent Democracy In
                    Fashion.Fashion Is About Dressing According To What's Fashionable.</p>
            </div>
        </div>
    </div>
</template>