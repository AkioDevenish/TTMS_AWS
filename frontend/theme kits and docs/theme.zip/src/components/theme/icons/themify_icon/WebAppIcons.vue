<template>
    <Card3 colClass="col-sm-12" title="Web App Icons" headerTitle="true">
        <div class="row icon-lists">

            <div class="col-sm-6 col-md-6 col-lg-4" v-for="(web, index) in webapp" :key="index"
                v-on:click="icon_bar(web.name)">
                <i class="" :class="web.name"></i>{{ web.name }}
            </div>

        </div>
    </Card3>
</template>
<script lang="ts" setup>
import { ref, defineEmits, defineAsyncComponent } from 'vue';
const Card3 = defineAsyncComponent(() => import("@/components/common/card/CardData3.vue"))
let customAnimation = {
    enter: "animated bounce",
    exit: "animated bounce",
}
let emit = defineEmits(['selected'])
let icon_bar_status = ref<boolean>(false)
let select_icon = {
    class: '',
    tag: ''
}
let webapp = ref([{ name: 'icon-wand' }, { name: 'icon-save' }, { name: 'icon-save-alt' }, { name: 'icon-direction' }, { name: 'icon-direction-alt' }, { name: 'icon-user' }, { name: 'icon-link' }, { name: 'icon-unlink' }, { name: 'icon-trash' }, { name: 'icon-target' }, { name: 'icon-tag' }, { name: 'icon-desktop' }, { name: 'icon-tablet' }, { name: 'icon-mobile' }, { name: 'icon-email' }, { name: 'icon-star' }, { name: 'icon-spray' }, { name: 'icon-signal' }, { name: 'icon-shopping-cart' }, { name: 'icon-shopping-cart-full' }, { name: 'icon-settings' }, { name: 'icon-search' }, { name: 'icon-zoom-in' }, { name: 'icon-zoom-out' }, { name: 'icon-cut' }, { name: 'icon-ruler' }, { name: 'icon-ruler-alt-2' }, { name: 'icon-ruler-pencil' }, { name: 'icon-ruler-alt' }, { name: 'icon-bookmark' }, { name: 'icon-bookmark-alt' }, { name: 'icon-reload' }, { name: 'icon-plus' }, { name: 'icon-minus' }, { name: 'icon-close' }, { name: 'icon-pin' }, { name: 'icon-pencil' }, { name: 'icon-pencil-alt' }, { name: 'icon-paint-roller' }, { name: 'icon-paint-bucket' }, { name: 'icon-na' }, { name: 'icon-medall' }, { name: 'icon-medall-alt' }, { name: 'icon-marker' }, { name: 'icon-marker-alt' }, { name: 'icon-lock' }, { name: 'icon-unlock' }, { name: 'icon-location-arrow' }, { name: 'icon-layout' }, { name: 'icon-layers' }, { name: 'icon-layers-alt' }, { name: 'icon-key' }, { name: 'icon-image' }, { name: 'icon-heart' }, { name: 'icon-heart-broken' }, { name: 'icon-hand-stop' }, { name: 'icon-hand-open' }, { name: 'icon-hand-drag' }, { name: 'icon-flag' }, { name: 'icon-flag-alt' }, { name: 'icon-flag-alt-2' }, { name: 'icon-eye' }, { name: 'icon-import' }, { name: 'icon-export' }, { name: 'icon-cup' }, { name: 'icon-crown' }, { name: 'icon-comments' }, { name: 'icon-comment' }, { name: 'icon-comment-alt' }, { name: 'icon-thought' }, { name: 'icon-clip' }, { name: 'icon-check' }, { name: 'icon-check-box' }, { name: 'icon-camera' }, { name: 'icon-announcement' }, { name: 'icon-brush' }, { name: 'icon-brush-alt' }, { name: 'icon-palette' }, { name: 'icon-briefcase' }, { name: 'icon-bolt' }, { name: 'icon-bolt-alt' }, { name: 'icon-blackboard' }, { name: 'icon-bag' }, { name: 'icon-world' }, { name: 'icon-wheelchair' }, { name: 'icon-car' }, { name: 'icon-truck' }, { name: 'icon-timer' }, { name: 'icon-ticket' }, { name: 'icon-thumb-up' }, { name: 'icon-thumb-down' }, { name: 'icon-stats-up' }, { name: 'icon-stats-down' }, { name: 'icon-shine' }, { name: 'icon-shift-right' }, { name: 'icon-shift-left' }, { name: 'icon-shift-right-alt' }, { name: 'icon-shift-left-alt' }, { name: 'icon-shield' }, { name: 'icon-notepad' }, { name: 'icon-server' }, { name: 'icon-pulse' }, { name: 'icon-printer' }, { name: 'icon-power-off' }, { name: 'icon-plug' }, { name: 'icon-pie-chart' }, { name: 'icon-panel' }, { name: 'icon-package' }, { name: 'icon-music' }, { name: 'icon-music-alt' }, { name: 'icon-mouse' }, { name: 'icon-mouse-alt' }, { name: 'icon-money' }, { name: 'icon-microphone' }, { name: 'icon-menu' }, { name: 'icon-menu-alt' }, { name: 'icon-map' }, { name: 'icon-map-alt' }, { name: 'icon-location-pin' }, { name: 'icon-light-bulb' }, { name: 'icon-info' }, { name: 'icon-infinite' }, { name: 'icon-id-badge' }, { name: 'icon-hummer' }, { name: 'icon-home' }, { name: 'icon-help' }, { name: 'icon-headphone' }, { name: 'icon-harddrives' }, { name: 'icon-harddrive' }, { name: 'icon-gift' }, { name: 'icon-game' }, { name: 'icon-filter' }, { name: 'icon-files' }, { name: 'icon-file' }, { name: 'icon-zip' }, { name: 'icon-folder' }, { name: 'icon-envelope' }, { name: 'icon-dashboard' }, { name: 'icon-cloud' }, { name: 'icon-cloud-up' }, { name: 'icon-cloud-down' }, { name: 'icon-clipboard' }, { name: 'icon-calendar' }, { name: 'icon-book' }, { name: 'icon-bell' }, { name: 'icon-basketball' }, { name: 'icon-bar-chart' }, { name: 'icon-bar-chart-alt' }, { name: 'icon-archive' }, { name: 'icon-anchor' }, { name: 'icon-alert' }, { name: 'icon-alarm-clock' }, { name: 'icon-agenda' }, { name: 'icon-write' }, { name: 'icon-wallet' }, { name: 'icon-video-clapper' }, { name: 'icon-video-camera' }, { name: 'icon-vector' }, { name: 'icon-support' }, { name: 'icon-stamp' }, { name: 'icon-slice' }, { name: 'icon-shortcode' }, { name: 'icon-receipt' }, { name: 'icon-pin2' }, { name: 'icon-pin-alt' }, { name: 'icon-pencil-alt2' }, { name: 'icon-eraser' }, { name: 'icon-more' }, { name: 'icon-more-alt' }, { name: 'icon-microphone-alt' }, { name: 'icon-magnet' }, { name: 'icon-line-double' }, { name: 'icon-line-dotted' }, { name: 'icon-line-dashed' }, { name: 'icon-ink-pen' }, { name: 'icon-info-alt' }, { name: 'icon-help-alt' }, { name: 'icon-headphone-alt' }, { name: 'icon-gallery' }, { name: 'icon-face-smile' }, { name: 'icon-face-sad' }, { name: 'icon-credit-card' }, { name: 'icon-comments-smiley' }, { name: 'icon-time' }, { name: 'icon-share' }, { name: 'icon-share-alt' }, { name: 'icon-rocket' }, { name: 'icon-new-window' }, { name: 'icon-rss' }, { name: 'icon-rss-alt' }])
function icon_bar(icon: string) {

    emit('selected', icon);
}
</script>
<style lang="scss" scoped>
@import "@/assets/scss/vendors/animate.scss"
</style>