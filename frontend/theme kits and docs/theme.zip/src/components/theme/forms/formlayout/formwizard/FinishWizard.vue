<template>
    <div class="tab-pane fade shipping-wizard finish-wizard1" id="finish-wizard" role="tabpanel"
        aria-labelledby="finish-wizard-tab">
        <div class="order-confirm"><img src="@/assets/images/gif/dashboard-8/successful.gif" alt="popper">
            <h5>Thank you! Your order is confirmed.</h5>
            <p class="mb-0">An email with your order's specifics will be sent to you as order confirmation.</p>
            <p class="text-center f-w-500 mt-2">Order ID: <a class="text-decoration-underline"
                    href="javascript:void(0)">GE34598 </a></p>
        </div>
    </div>
</template>