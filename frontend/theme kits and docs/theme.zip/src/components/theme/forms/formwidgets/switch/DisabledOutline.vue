<template>
    <Card3 colClass="col-md-6" cardbodyClass="common-flex " pre="true" preClass="f-m-light mt-1" headerTitle="true"
        title="Disabled outline switch" :desc="desc">
        <div class="d-flex" v-for="(item, index) in disable" :key="index">
            <div class="flex-grow-1 text-end icon-state switch-outline">
                <label class="switch mb-0">
                    <input type="checkbox"><span class="switch-state " :class="item.class"></span>
                </label>
            </div>
        </div>
    </Card3>
</template>
<script lang="ts" setup>
import { ref, defineAsyncComponent } from 'vue'
import { disable } from "@/core/data/forms"
const Card3 = defineAsyncComponent(() => import("@/components/common/card/CardData3.vue"))
let desc = ref<string>("Use the <code>.switch-outline </code> class through created outline.  ")
</script>