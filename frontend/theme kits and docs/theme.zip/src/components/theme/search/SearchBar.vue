<template>
    <div class="card-header">
        <form class="theme-form">
            <div class="input-group m-0 flex-nowrap">
                <input class="form-control-plaintext" type="search" placeholder="Pixelstrap .."><span
                    class="btn btn-primary input-group-text">Search</span>
            </div>
        </form>
    </div>
</template>